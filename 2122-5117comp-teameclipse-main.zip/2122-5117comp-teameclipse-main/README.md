# 5117COMP-AS1 *(A Climate Data Analysis System)*
## Team Eclipse
* Anthony Bacon

* Luka Ginley

* Matthew Coulton

* Rachel Matonhodze

* Sam Forber-Jones

## Application entry point (unoptimised version)

Path: src/unoptimised/logic/ClimateDataAnalyser

Run configuration "*ClimateDataAnalyser (UNOPTIMISED).launch*" included in project root
## Application entry point (optimised version)

Path: src/optimised/logic/ClimateDataAnalyser

Run configuration "*ClimateDataAnalyser (OPTIMISED).launch*" included in project root