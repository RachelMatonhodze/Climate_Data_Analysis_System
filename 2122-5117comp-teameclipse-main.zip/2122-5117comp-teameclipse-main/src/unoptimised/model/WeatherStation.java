package unoptimised.model;
import java.util.ArrayList;

public class WeatherStation {
	private String name;
	public ArrayList<WeatherObservation> observations;

	public WeatherStation(String name, ArrayList<WeatherObservation> observations) {
		this.name = name;
		this.observations = observations;
	}
	
	@Override
	public String toString() {
		return getName();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
