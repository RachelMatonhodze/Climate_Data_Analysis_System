package unoptimised.logic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import unoptimised.io.*;
import unoptimised.model.*;

public class ClimateDataAnalyser {
	private static final Scanner scanner = new Scanner(System.in);
	private static ArrayList<WeatherStation> stationList;

	static Scanner userInput = new Scanner(System.in);

	public static void main(String[] args) throws IOException {
		// Create ArrayList of WeatherStations,
		// each containing a list of WeatherObservations
		stationList = FileParser.importWeatherData();
		menu();
	}

	public static void menu() throws IOException {
		String menuSelection = "";
		while (true) {
			do {
				System.out.println("Main Menu\n-------------------------------\n" + "Options:\n"
						+ "A: List all recording locations\n"
						+ "B: List all weather observations (specified location)\n"
						+ "C: List all weather observations (specified month / year)\n"
						+ "D: Find minimum and maximum recorded temperatures along with date of recording (specified location)\n"
						+ "E: Find location with minimum and maximum rainfall, hours of sun, or temperature (all-time)\n"
						+ "F: Find location with minimum and maximum rainfall, hours of sun, or temperature (specified month / year)\n"
						+ "G: List recording locations in chronological order of first weather measurement\n"
						+ "H: SHOWCASE FEATURE\n" + "\nR: Regenerate CSVs from txt directory\n\n" + "Q: Quit");
				menuSelection = scanner.nextLine().toLowerCase();
			} while (!menuSelection.matches("a|b|c|d|e|f|g|h|r|q"));

			switch (menuSelection) {
			case "a":
				featureA();
				break;
			case "b":
				featureB();
				break;
			case "c":
				featureC();
				break;
			case "d":
				featureD();
				break;
			case "e":
				featureE(selectSubfeature());
				break;
			case "f":
				featureF(selectSubfeature(), getValidDate());
				break;
			case "g":
				featureG();
				break;
			case "h":
				featureH();
				break;
			case "r":
				FileParser.generateCSVs();
				stationList = FileParser.importWeatherData();
				break;
			case "q":
				System.out.println("---Program terminated---");
				return;
			default:
				System.err.println("Error: Main menu, input not matched");
				return;
			}
		}
	}

	private static void featureA() {

		for (WeatherStation station : stationList) {
			System.out.println(station.getName());
		}
		System.out.println();

	}

	private static void featureB() throws IOException {
		boolean found = false;
		while (!found) {

			featureA();
			System.out.println("Please enter a location for which you wish to view a locations data:  ");
			String userInput = scanner.nextLine();

			for (int i = 0; i < stationList.size(); i++) {
				WeatherStation station = stationList.get(i); // Goes through the list of stations until the if statement
																// below finds a match
				if (station.getName().equalsIgnoreCase(userInput)) { // Detects when the String entered by the user
																		// matches the String of the name of the station
					found = true; // Sets the boolean to true so that the while loop can continue
					System.err.println("Location found " + userInput);
					ArrayList<WeatherObservation> observations = station.observations;
					Collections.sort(observations, new Comparator<WeatherObservation>() {
						public int compare(WeatherObservation s1, WeatherObservation s2) {
							// Sorting algorithm to make the ArrayList into chronological order
							int result = Integer.compare(s1.getYear(), s2.getYear());
							if (result == 0) { // When it detects that there is no change in year it will then begin to
												// sort the months within that year set
								result = Integer.valueOf(s1.getMonth()).compareTo(s2.getMonth());
							}
							return result;
						}
					});

					System.out.println("Date\tMaxTemp\tMinTemp\tFrostyDays\tRainInMM\tHoursOfSun");
					for (int k = 0; k < observations.size(); k++) { // Iterates through observation's rows and outputs
																	// them in a table style accordingly
						WeatherObservation observation = observations.get(k);
						System.out.println(
								observation.getYear() + "/" + observation.getMonth() + "\t" + observation.getMaxTemp()
										+ "\t" + observation.getMinTemp() + "\t" + observation.getFrostyDays() + "\t"
										+ "\t" + observation.getRainInMM() + "\t" + "\t" + observation.getHoursOfSun()); // \t
						// outputs the data in columns to be more organised
					}
				}
			}
			if (!found) {
				System.err.println(
						"Error: The station you have entered we either have no data for or is not a valid input.");
				featureB();
			}
		}
	}

	private static void featureC() {
		int[] userDate = getValidDate();
		int year = userDate[0];
		int month = userDate[1];

		boolean found = false;
		for (int i = 0; i < stationList.size(); i++) {
			WeatherStation station = stationList.get(i);
			System.out.println("Station name: " + station.getName());
			ArrayList<WeatherObservation> observations = station.observations;
			// If entered month & year matches, print Weather Observation informat ion
			for (int k = 0; k < observations.size(); k++) {
				WeatherObservation observation = observations.get(k);
				if (year == observations.get(k).getYear()) {
					if (month == observations.get(k).getMonth()) {
						System.out.println("Date: " + observation.getYear() + "/" + observation.getMonth()
								+ " MaxTemp: " + observation.getMaxTemp() + " MinTemp: " + observation.getMinTemp()
								+ " FrostyDays: " + observation.getFrostyDays() + " RainInMM: "
								+ observation.getRainInMM() + " HoursOfSun: " + observation.getHoursOfSun());
						// Set boolean true and break
						found = true;
						break;
					}
				}
			}
		}
		// Outside the look check if entered month or year does not match, print invalid
		// Date
		if (!found) {
			System.out.println("Invalid date!");
		}
	}

	public static void featureD() throws IOException {

		boolean found = false;	// Create boolean, if a location is found make boolean true
		while (!found) {

			featureA();
			System.out.println(
					"Please enter a location for which you wish to view the minimum and maximum temperatures: ");
			String userInput = scanner.nextLine();

			for (int i = 0; i < stationList.size(); i++) {		// For loop to iterate over stations
				WeatherStation station = stationList.get(i);
				ArrayList<WeatherObservation> observations = station.observations;
				Double localMaximum = observations.get(0).getMaxTemp();
				Double localMinimum = observations.get(0).getMinTemp();
				int month = observations.get(0).getMonth();
				int year = observations.get(0).getYear();
				if (station.getName().equalsIgnoreCase(userInput)) {
					found = true;	// Matches station to a user input
					int maxIndex = 0;
					int minIndex = 0;
					for (int k = 0; k < observations.size(); k++) {		// For loop to iterate over observations
						Double maxValue = observations.get(k).getMaxTemp();
						Double minValue = observations.get(k).getMinTemp();
						month = observations.get(0).getMonth();
						year = observations.get(0).getYear();
						if (maxValue != null) {			// Compare max values, set new localMaximum to maxValue if the next number found is larger
							if (localMaximum == null || maxValue > localMaximum) {
								localMaximum = maxValue;
								maxIndex = k;
							}
						}
						if (minValue != null) {		// Compare min values, set new localMaximum to maxValue if the next number found is smaller
							if (localMinimum == null || minValue < localMinimum) {
								localMinimum = minValue;
								minIndex = k;
							}
						}
					}

					WeatherObservation maxObservation = observations.get(maxIndex);		// Get row of observations for station with max variable found
					WeatherObservation minObservation = observations.get(minIndex);		// Get row of observations for station with min variable found

					System.out.println("Minimum temperature for " + userInput + " was: " + localMinimum + "°"		// Print minimum temperature to user
							+ " recorded in " + minObservation.getMonth() + "/" + minObservation.getYear());
					System.out.println("Maximum temperature for " + userInput + " was: " + localMaximum + "°"		// Print maximum temperature to user
							+ " recorded in " + maxObservation.getMonth() + "/" + maxObservation.getYear());
					break;
				}
			}
			if (!found) {
				System.out.println(
						"Error: The station you have entered we either have no data for or is not a valid input.");
				break;
			}
		}
	}

	private static void featureE(String valueSelection) { // Maximum / minimum (all time)
		WeatherStation maxStation = stationList.get(0);
		WeatherStation minStation = maxStation;
		Double globalMax = null;
		Double globalMin = null;

		switch (valueSelection) {
		case "1": // Rainfall
			for (WeatherStation station : stationList) {
				ArrayList<WeatherObservation> observations = station.observations;
				// Find station-level maximum and minimum
				Double localMax = null;
				Double localMin = null;
				for (WeatherObservation observation : observations) {
					Double value = observation.getRainInMM();
					if (value != null) {
						if (localMax == null || value > localMax) {
							localMax = value;
						}
						if (localMin == null || value < localMin) {
							localMin = value;
						}
					}
				}
				// Compare station-level max and min to global max and min
				// Set new global max/min if appropriate
				if (localMax != null) {
					if (globalMax == null || localMax > globalMax) {
						globalMax = localMax;
						maxStation = station;
					}
				}
				if (localMin != null) {
					if (globalMin == null || localMin < globalMin) {
						globalMin = localMin;
						minStation = station;
					}
				}
			}
			break;
		case "2": // Hours of sun
			for (WeatherStation station : stationList) {
				ArrayList<WeatherObservation> observations = station.observations;
				// Find station-level maximum and minimum
				Double localMax = null;
				Double localMin = null;
				for (WeatherObservation observation : observations) {
					Double value = observation.getHoursOfSun();
					if (value != null) {
						if (localMax == null || value > localMax) {
							localMax = value;
						}
						if (localMin == null || value < localMin) {
							localMin = value;
						}
					}
				}
				// Compare station-level max and min to global max and min
				// Set new global max/min if appropriate
				if (localMax != null) {
					if (globalMax == null || localMax > globalMax) {
						globalMax = localMax;
						maxStation = station;
					}
				}
				if (localMin != null) {
					if (globalMin == null || localMin < globalMin) {
						globalMin = localMin;
						minStation = station;
					}
				}
			}
			break;
		case "3": // Temperature
			for (WeatherStation station : stationList) {
				ArrayList<WeatherObservation> observations = station.observations;
				// Find station-level maximum and minimum
				Double localMax = null;
				Double localMin = null;
				for (WeatherObservation observation : observations) {
					Double maxValue = observation.getMaxTemp();
					Double minValue = observation.getMinTemp();
					if (maxValue != null) {
						if (localMax == null || maxValue > localMax) {
							localMax = maxValue;
						}
					}
					if (minValue != null) {
						if (localMin == null || minValue < localMin) {
							localMin = minValue;
						}
					}
				}
				// Compare station-level max and min to global max and min
				// Set new global max/min if appropriate
				if (localMax != null) {
					if (globalMax == null || localMax > globalMax) {
						globalMax = localMax;
						maxStation = station;
					}
				}
				if (localMin != null) {
					if (globalMin == null || localMin < globalMin) {
						globalMin = localMin;
						minStation = station;
					}
				}
			}
			break;
		default:
			System.err.println("Error: Feature E menu, input not matched");
			return;
		}

		switch (valueSelection) {
		case "1":
			System.out.println("All-time rainfall maximum of " + globalMax + "mm recorded at " + maxStation);
			System.out.println("All-time rainfall minimum of " + globalMin + "mm recorded at " + minStation);
			break;
		case "2":
			System.out.println("All-time sunlight maximum of " + globalMax + " hours recorded at " + maxStation);
			System.out.println("All-time sunlight minimum of " + globalMin + " hours recorded at " + minStation);
			break;
		case "3":
			System.out.println("All-time temperature maximum of " + globalMax + " degrees C recorded at " + maxStation);
			System.out.println("All-time temperature minimum of " + globalMin + " degrees C recorded at " + minStation);
			break;
		default:
			System.err.println("Error: Feature E menu, input not matched");
			return;
		}

	}

	private static String selectSubfeature() {
		String valueSelection = null;
		do {
			System.out.println("Value to find maximum and minimum of:\n-------------------------------\n"
					+ "Options:\n1: Rainfall\n2: Hours of sun\n3: Temperature");
			valueSelection = scanner.nextLine();
		} while (!valueSelection.matches("1|2|3"));
		return valueSelection;
	}

	private static int[] getValidDate() {
		int selectedYear;
		int selectedMonth;
		while (true) {
			try {
				System.out.print("Enter year: ");
				selectedYear = Integer.valueOf(scanner.nextLine());
			} catch (NumberFormatException e) {
				System.out.println("Error: Invalid year");
				continue;
			}
			break;
		}
		while (true) {
			try {
				System.out.print("Enter month: ");
				selectedMonth = Integer.valueOf(scanner.nextLine());
				if (selectedMonth < 1 || selectedMonth > 12) {
					System.out.println("Error: Invalid month");
					continue;
				}
			} catch (NumberFormatException e) {
				System.out.println("Error: Invalid month");
				continue;
			}
			break;
		}
		int[] date = { selectedYear, selectedMonth };
		return date;

	}

	private static void featureF(String valueSelection, int[] userDate) {
		// Maximum / minimum (specified month and year)
		int selectedYear = userDate[0];
		int selectedMonth = userDate[1];

		WeatherStation maxStation = stationList.get(0);
		WeatherStation minStation = maxStation;
		Double globalMax = null;
		Double globalMin = null;

		switch (valueSelection) {
		case "1": // Rainfall
			for (WeatherStation station : stationList) {
				ArrayList<WeatherObservation> observations = station.observations;
				// Find station-level value for specified date
				Double localValue = null;
				for (WeatherObservation observation : observations) {
					if ((observation.getYear() == selectedYear) && (observation.getMonth() == selectedMonth)) {
						localValue = observation.getRainInMM();
						break;
					}
				}
				// Compare station-level value to global max and min
				// Set new global max/min if appropriate
				if (localValue != null) {
					if (globalMax == null || localValue > globalMax) {
						globalMax = localValue;
						maxStation = station;
					}
					if (globalMin == null || localValue < globalMin) {
						globalMin = localValue;
						minStation = station;
					}
				}
			}
			break;
		case "2": // Hours of sun
			for (WeatherStation station : stationList) {
				ArrayList<WeatherObservation> observations = station.observations;
				// Find station-level value for specified date
				Double localValue = null;
				for (WeatherObservation observation : observations) {
					if ((observation.getYear() == selectedYear) && (observation.getMonth() == selectedMonth)) {
						localValue = observation.getHoursOfSun();
						break;
					}
				}
				// Compare station-level value to global max and min
				// Set new global max/min if appropriate
				if (localValue != null) {
					if (globalMax == null || localValue > globalMax) {
						globalMax = localValue;
						maxStation = station;
					}
					if (globalMin == null || localValue < globalMin) {
						globalMin = localValue;
						minStation = station;
					}
				}
			}
			break;
		case "3": // Temperature
			for (WeatherStation station : stationList) {
				ArrayList<WeatherObservation> observations = station.observations;
				// Find station-level max/min for specified date
				Double localMax = null;
				Double localMin = null;
				for (WeatherObservation observation : observations) {
					if ((observation.getYear() == selectedYear) && (observation.getMonth() == selectedMonth)) {
						localMax = observation.getMaxTemp();
						localMin = observation.getMinTemp();
						break;
					}
				}
				// Compare station-level max/min to global max and min
				// Set new global max/min if appropriate
				if (localMax != null) {
					if (globalMax == null || localMax > globalMax) {
						globalMax = localMax;
						maxStation = station;
					}
				}
				if (localMin != null) {
					if (globalMin == null || localMin < globalMin) {
						globalMin = localMin;
						minStation = station;
					}
				}

			}
			break;
		default:
			System.err.println("Error: Feature F menu, input not matched");
			return;
		}

		if (globalMax == null) {
			System.out.println("No values found for " + selectedYear + "-" + selectedMonth + ", try a different date");

		} else {
			switch (valueSelection) {
			case "1":
				System.out.println(selectedYear + "-" + selectedMonth + " rainfall maximum of " + globalMax
						+ "mm recorded at " + maxStation);
				System.out.println(selectedYear + "-" + selectedMonth + " rainfall minimum of " + globalMin
						+ "mm recorded at " + minStation);
				break;
			case "2":
				System.out.println(selectedYear + "-" + selectedMonth + " sunlight maximum of " + globalMax
						+ " hours recorded at " + maxStation);
				System.out.println(selectedYear + "-" + selectedMonth + " sunlight minimum of " + globalMin
						+ " hours recorded at " + minStation);
				break;
			case "3":
				System.out.println(selectedYear + "-" + selectedMonth + " temperature maximum of " + globalMax
						+ " degrees C recorded at " + maxStation);
				System.out.println(selectedYear + "-" + selectedMonth + " temperature minimum of " + globalMin
						+ " degrees C recorded at " + minStation);
				break;
			default:
				System.err.println("Error: Feature F menu, input not matched");
				return;
			}
		}

	}

	private static void featureG() {
		WeatherObservation[] firstObservations = new WeatherObservation[stationList.size()];
		int[] observationStations = new int[stationList.size()];

		// firstObservation stores the first observation from each station i as
		// firstObservations[i]
		// observationStations stores the index of each station i within stationList as
		// observationStations[i], so observations can be mapped back to their origin
		// station, after sorting
		for (int i = 0; i < stationList.size(); i++) {
			WeatherStation station = stationList.get(i);
			WeatherObservation first = station.observations.get(0);
			for (WeatherObservation observation : station.observations) {
				if (observation.compareTo(first) < 0) {
					first = observation;
				}
			}
			firstObservations[i] = first;
			observationStations[i] = i;
		}
		// Sort firstObservations and observationStations, based on the values in
		// firstObservations
		for (int i = 1; i < firstObservations.length; i++) {
			for (int j = i; j > 0 && firstObservations[j - 1].compareTo(firstObservations[j]) > 0; j--) {
				WeatherObservation temp = firstObservations[j - 1];
				int tempObsStations = observationStations[j - 1];
				firstObservations[j - 1] = firstObservations[j];
				observationStations[j - 1] = observationStations[j];
				firstObservations[j] = temp;
				observationStations[j] = tempObsStations;
			}
		}

		// Printing tabulated results
		System.out.println("Recording locations in chronological order of first measurement:");
		System.out.printf("%1$-29s", "Weather station");
		System.out.print("Earliest recording" + "\n");
		for (int i = 0; i < observationStations.length; i++) {
			WeatherStation station = stationList.get(observationStations[i]);
			WeatherObservation observation = firstObservations[i];
			System.out.printf("%1$-29s", station.getName());
			System.out.print(observation.getYear() + "-" + observation.getMonth() + "\n");
		}
		System.out.println("-----------------------------------------\n");
	}

	private static void featureH() {
		System.err.println("Feature H not yet implemented");
	}

}
