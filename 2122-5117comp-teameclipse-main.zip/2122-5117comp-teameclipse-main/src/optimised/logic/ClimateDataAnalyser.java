package optimised.logic;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.Scanner;
import optimised.io.*;
import optimised.model.*;

public class ClimateDataAnalyser {
	private static final Scanner scanner = new Scanner(System.in);
	private static HashMap<String, WeatherStation> stationMap;

	static Scanner userInput = new Scanner(System.in);

	public static void main(String[] args) throws IOException {
		// Create ArrayList of WeatherStations,
		// each containing a list of WeatherObservations
		stationMap = FileParser.importWeatherData();
		menu();
	}

	public static void menu() throws IOException {
		String menuSelection = "";
		while (true) {
			do {
				System.out.println("Main Menu\n-------------------------------\n" + "Options:\n"
						+ "A: List all recording locations\n"
						+ "B: List all weather observations (specified location)\n"
						+ "C: List all weather observations (specified month / year)\n"
						+ "D: Find minimum and maximum recorded temperatures along with date of recording (specified location)\n"
						+ "E: Find location with minimum and maximum rainfall, hours of sun, or temperature (all-time)\n"
						+ "F: Find location with minimum and maximum rainfall, hours of sun, or temperature (specified month / year)\n"
						+ "G: List recording locations in chronological order of first weather measurement\n"
						+ "H: SHOWCASE FEATURE\n" + "\nR: Regenerate CSVs from txt directory\n\n" + "Q: Quit");
				menuSelection = scanner.nextLine().toLowerCase();
			} while (!menuSelection.matches("a|b|c|d|e|f|g|h|r|q"));

			switch (menuSelection) {
			case "a":
				featureA();
				break;
			case "b":
				featureB();
				break;
			case "c":
				featureC();
				break;
			case "d":
				featureD();
				break;
			case "e":
				featureE(selectSubfeature());
				break;
			case "f":
				featureF(selectSubfeature(), getValidDate());
				break;
			case "g":
				featureG();
				break;
			case "h":
				featureH();
				break;
			case "r":
				FileParser.generateCSVs();
				stationMap = FileParser.importWeatherData();
				break;
			case "q":
				System.out.println("---Program terminated---");
				return;
			default:
				System.err.println("Error: Main menu, input not matched");
				return;
			}
		}
	}

	private static void featureA() {

		for (WeatherStation station : stationMap.values()) {
			System.out.println(station.getName());
		}
		System.out.println();

	}

	private static void featureB() throws IOException {
		
		boolean found = false;
		
		while (!found) {
			
			featureA();
			System.out.println("Please enter a location for which you wish to view a locations data:  ");
			String userInput = scanner.nextLine();

			for (WeatherStation station : stationMap.values()) {
				TreeMap<String, WeatherObservation> observations = station.observations;
				if (station.getName().equalsIgnoreCase(userInput)) { 
					found = true; //ends the while loop
					System.err.println("Location found " + userInput);
					for (Map.Entry<String, WeatherObservation> entry : observations.entrySet()) {
			            WeatherObservation observation = entry.getValue();
			        }
					System.out.println("Date\tMaxTemp\tMinTemp\tFrostyDays\tRainInMM\tHoursOfSun");
					for (WeatherObservation observation : observations.values()) { 
						System.out.println(
								observation.getYear() + "/" + observation.getMonth() + "\t" + observation.getMaxTemp()
										+ "\t" + observation.getMinTemp() + "\t" + observation.getFrostyDays() + "\t"
										+ "\t" + observation.getRainInMM() + "\t" + "\t" + observation.getHoursOfSun()); // \t
						// outputs the data in collums to be more organised
					}
				}
			}
			if (!found) {
				System.err.println(
						"Error: The station you have entered we either have no data for or is not a valid input.");
				featureB();
			}
		}
	}

	private static void featureC() {

		int[] userDate = getValidDate();
		int year = userDate[0];
		int month = userDate[1];

		boolean found = false;
		for (WeatherStation station : stationMap.values()) {
			System.out.println("Station name: " + station.getName());
			TreeMap<String, WeatherObservation> observations = station.observations;
			// If entered month & year matches, print Weather Observation informat ion
			for (WeatherObservation observation : observations.values()) {
				if (year == observation.getYear()) {
					if (month == observation.getMonth()) {
						System.out.println("Date: " + observation.getYear() + "/" + observation.getMonth()
								+ " MaxTemp: " + observation.getMaxTemp() + " MinTemp: " + observation.getMinTemp()
								+ " FrostyDays: " + observation.getFrostyDays() + " RainInMM: "
								+ observation.getRainInMM() + " HoursOfSun: " + observation.getHoursOfSun());
						// Set boolean true and break
						found = true;
						break;
					}
				}
			}
		}
		// Outside the look check if entered month or year does not match, print invalid
		// Date
		if (!found) {
			System.out.println("Error! Please try again");
		}
	}

	public static void featureD() throws IOException {
		boolean found = false;
		while (!found) {
			featureA();
			System.out.println(
					"Please enter a location for which you wish to view the minimum and maximum temperatures: ");
			String userInput = scanner.nextLine();

			for (WeatherStation station : stationMap.values()) {
				TreeMap<String, WeatherObservation> observations = station.observations;
				Double localMaximum = null;
				Double localMinimum = null;
				if (station.getName().equalsIgnoreCase(userInput)) {
					found = true;
					WeatherObservation maxIndex = null;
					WeatherObservation minIndex = null;
					for (WeatherObservation observation : observations.values()) {
						Double maxValue = observation.getMaxTemp();
						Double minValue = observation.getMinTemp();
						if (maxValue != null) {
							if (localMaximum == null || maxValue > localMaximum) {
								localMaximum = maxValue;
								maxIndex = observation;
							}
						}
						if (minValue != null) {
							if (localMinimum == null || minValue < localMinimum) {
								localMinimum = minValue;
								minIndex = observation;
							}
						}
					}

					System.out.println("Minimum temperature for " + userInput + " was: " + localMinimum + "°"
							+ " recorded in " + minIndex.getMonth() + "/" + minIndex.getYear());
					System.out.println("Maximum temperature for " + userInput + " was: " + localMaximum + "°"
							+ " recorded in " + maxIndex.getMonth() + "/" + maxIndex.getYear());
					break;

				}
			}
			if (!found) {
				System.out.println(
						"Error: The station you have entered we either have no data for or is not a valid input.");
				break;
			}
		}
	}

	private static String selectSubfeature() {
		String valueSelection = null;
		do {
			System.out.println("Value to find maximum and minimum of:\n-------------------------------\n"
					+ "Options:\n1: Rainfall\n2: Hours of sun\n3: Temperature");
			valueSelection = scanner.nextLine();
		} while (!valueSelection.matches("1|2|3"));
		return valueSelection;
	}

	private static void featureE(String valueSelection) { // Maximum / minimum (all time)
		WeatherStation maxStation = null;
		WeatherStation minStation = null;
		Double globalMax = null;
		Double globalMin = null;

		switch (valueSelection) {
		case "1": // Rainfall
			for (WeatherStation station : stationMap.values()) {
				TreeMap<String, WeatherObservation> observations = station.observations;
				// Find station-level maximum and minimum
				Double localMax = null;
				Double localMin = null;
				for (WeatherObservation observation : observations.values()) {
					Double value = observation.getRainInMM();
					if (value != null) {
						if (localMax == null || value > localMax) {
							localMax = value;
						}
						if (localMin == null || value < localMin) {
							localMin = value;
						}
					}
				}
				// Compare station-level max and min to global max and min
				// Set new global max/min if appropriate
				if (localMax != null) {
					if (globalMax == null || localMax > globalMax) {
						globalMax = localMax;
						maxStation = station;
					}
				}
				if (localMin != null) {
					if (globalMin == null || localMin < globalMin) {
						globalMin = localMin;
						minStation = station;
					}
				}
			}
			break;
		case "2": // Hours of sun
			for (WeatherStation station : stationMap.values()) {
				TreeMap<String, WeatherObservation> observations = station.observations;
				// Find station-level maximum and minimum
				Double localMax = null;
				Double localMin = null;
				for (WeatherObservation observation : observations.values()) {
					Double value = observation.getHoursOfSun();
					if (value != null) {
						if (localMax == null || value > localMax) {
							localMax = value;
						}
						if (localMin == null || value < localMin) {
							localMin = value;
						}
					}
				}
				// Compare station-level max and min to global max and min
				// Set new global max/min if appropriate
				if (localMax != null) {
					if (globalMax == null || localMax > globalMax) {
						globalMax = localMax;
						maxStation = station;
					}
				}
				if (localMin != null) {
					if (globalMin == null || localMin < globalMin) {
						globalMin = localMin;
						minStation = station;
					}
				}
			}
			break;
		case "3": // Temperature
			for (WeatherStation station : stationMap.values()) {
				TreeMap<String, WeatherObservation> observations = station.observations;
				// Find station-level maximum and minimum
				Double localMax = null;
				Double localMin = null;
				for (WeatherObservation observation : observations.values()) {
					Double maxValue = observation.getMaxTemp();
					Double minValue = observation.getMinTemp();
					if (maxValue != null) {
						if (localMax == null || maxValue > localMax) {
							localMax = maxValue;
						}
					}
					if (minValue != null) {
						if (localMin == null || minValue < localMin) {
							localMin = minValue;
						}
					}
				}
				// Compare station-level max and min to global max and min
				// Set new global max/min if appropriate
				if (localMax != null) {
					if (globalMax == null || localMax > globalMax) {
						globalMax = localMax;
						maxStation = station;
					}
				}
				if (localMin != null) {
					if (globalMin == null || localMin < globalMin) {
						globalMin = localMin;
						minStation = station;
					}
				}
			}
			break;
		default:
			System.err.println("Error: Feature E menu, input not matched");
			return;
		}

		switch (valueSelection) {
		case "1":
			System.out.println("All-time rainfall maximum of " + globalMax + "mm recorded at " + maxStation);
			System.out.println("All-time rainfall minimum of " + globalMin + "mm recorded at " + minStation);
			break;
		case "2":
			System.out.println("All-time sunlight maximum of " + globalMax + " hours recorded at " + maxStation);
			System.out.println("All-time sunlight minimum of " + globalMin + " hours recorded at " + minStation);
			break;
		case "3":
			System.out.println("All-time temperature maximum of " + globalMax + " degrees C recorded at " + maxStation);
			System.out.println("All-time temperature minimum of " + globalMin + " degrees C recorded at " + minStation);
			break;
		default:
			System.err.println("Error: Feature E menu, input not matched");
			return;
		}

	}

	private static int[] getValidDate() {
		int selectedYear;
		int selectedMonth;
		while (true) {
			try {
				System.out.print("Enter year: ");
				selectedYear = Integer.valueOf(scanner.nextLine());
			} catch (NumberFormatException e) {
				System.out.println("Error: Invalid year");
				continue;
			}
			break;
		}
		while (true) {
			try {
				System.out.print("Enter month: ");
				selectedMonth = Integer.valueOf(scanner.nextLine());
				if (selectedMonth < 1 || selectedMonth > 12) {
					System.out.println("Error: Invalid month");
					continue;
				}
			} catch (NumberFormatException e) {
				System.out.println("Error: Invalid month");
				continue;
			}
			break;
		}
		int[] date = { selectedYear, selectedMonth };
		return date;

	}

	private static void featureF(String valueSelection, int[] userDate) { // Maximum / minimum (specified month and
																			// year)
		int selectedYear = userDate[0];
		int selectedMonth = userDate[1];
		String selectedDate = WeatherObservation.getDateKey(selectedYear, selectedMonth);

		WeatherStation maxStation = null;
		WeatherStation minStation = null;
		Double globalMax = null;
		Double globalMin = null;

		switch (valueSelection) {
		case "1": // Rainfall
			for (WeatherStation station : stationMap.values()) {
				WeatherObservation observation = station.observations.get(selectedDate);
				if (observation == null) {
					continue; // Date out of range for current station
				}
				// Compare station-level value to global max and min
				// Set new global max/min if appropriate
				Double localValue = observation.getRainInMM();
				if (localValue != null) {
					if (globalMax == null || localValue > globalMax) {
						globalMax = localValue;
						maxStation = station;
					}
					if (globalMin == null || localValue < globalMin) {
						globalMin = localValue;
						minStation = station;
					}
				}
			}
			break;
		case "2": // Hours of sun
			for (WeatherStation station : stationMap.values()) {
				WeatherObservation observation = station.observations.get(selectedDate);
				if (observation == null) {
					continue; // Date out of range for current station
				}
				// Compare station-level value to global max and min
				// Set new global max/min if appropriate
				Double localValue = observation.getHoursOfSun();
				if (localValue != null) {
					if (globalMax == null || localValue > globalMax) {
						globalMax = localValue;
						maxStation = station;
					}
					if (globalMin == null || localValue < globalMin) {
						globalMin = localValue;
						minStation = station;
					}
				}
			}
			break;
		case "3": // Temperature
			for (WeatherStation station : stationMap.values()) {
				WeatherObservation observation = station.observations.get(selectedDate);
				if (observation == null) {
					continue; // Date out of range for current station
				}
				// Compare station-level max/min to global max and min
				// Set new global max/min if appropriate
				Double localMax = observation.getMaxTemp();
				Double localMin = observation.getMinTemp();
				if (localMax != null) {
					if (globalMax == null || localMax > globalMax) {
						globalMax = localMax;
						maxStation = station;
					}
				}
				if (localMin != null) {
					if (globalMin == null || localMin < globalMin) {
						globalMin = localMin;
						minStation = station;
					}
				}

			}
			break;
		default:
			System.err.println("Error: Feature F menu, input not matched");
			return;
		}

		if (globalMax == null) {
			System.out.println("No values found for " + selectedYear + "-" + selectedMonth + ", try a different date");

		} else {
			switch (valueSelection) {
			case "1":
				System.out.println(selectedYear + "-" + selectedMonth + " rainfall maximum of " + globalMax
						+ "mm recorded at " + maxStation);
				System.out.println(selectedYear + "-" + selectedMonth + " rainfall minimum of " + globalMin
						+ "mm recorded at " + minStation);
				break;
			case "2":
				System.out.println(selectedYear + "-" + selectedMonth + " sunlight maximum of " + globalMax
						+ " hours recorded at " + maxStation);
				System.out.println(selectedYear + "-" + selectedMonth + " sunlight minimum of " + globalMin
						+ " hours recorded at " + minStation);
				break;
			case "3":
				System.out.println(selectedYear + "-" + selectedMonth + " temperature maximum of " + globalMax
						+ " degrees C recorded at " + maxStation);
				System.out.println(selectedYear + "-" + selectedMonth + " temperature minimum of " + globalMin
						+ " degrees C recorded at " + minStation);
				break;
			default:
				System.err.println("Error: Feature F menu, input not matched");
				return;
			}
		}
	}

	private static void featureG() {
		// Map earliest observations to the station which recorded them
		TreeMap<WeatherObservation, WeatherStation> firstObservations = new TreeMap<WeatherObservation, WeatherStation>();
		// Adding stations and their first observation to the map
		for (WeatherStation station : stationMap.values()) {
			WeatherObservation firstObservation = station.observations.firstEntry().getValue();
			firstObservations.put(firstObservation, station);
		}
		// Printing tabulated results
		System.out.println("Recording locations in chronological order of first measurement:");
		System.out.printf("%1$-29s", "Weather station");
		System.out.print("Earliest recording" + "\n");
		// TreeMap maintains natural ordering of keys, WeatherObservation implements
		// Comparable (based on chronological order)
		for (Map.Entry<WeatherObservation, WeatherStation> entry : firstObservations.entrySet()) {
			WeatherStation station = entry.getValue();
			WeatherObservation observation = entry.getKey();
			System.out.printf("%1$-29s", station.getName());
			System.out.print(observation.getYear() + "-" + observation.getMonth() + "\n");
		}
		System.out.println("-----------------------------------------\n");
	}

	private static void featureH() {
		System.err.println("Feature H not yet implemented");
	}

}
