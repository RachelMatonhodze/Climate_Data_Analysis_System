package optimised.model;

public class WeatherObservation implements Comparable<WeatherObservation> {
	// Note: this class has a natural ordering that is inconsistent with equals.
	private int year;
	private int month;
	private Double maxTemp;
	private Double minTemp;
	private Integer frostyDays;
	private Double rainInMM;
	private Double hoursOfSun;

	public WeatherObservation() {

	}

	@Override // Compares dates
	public int compareTo(WeatherObservation comp) {
		if (this.year == comp.year && this.month == comp.month) {
			if (this != comp) {
				// Don't treat observations from the same date as the same observation
				return -1;
			} else {
				// Unless from same station (i.e. same observation)
				return 0;
			}
		} else {
			if (this.year < comp.year) {
				return -1;
			} else if (this.year > comp.year) {
				return 1;
			} else { // If year is the same, check month
				if (this.month < comp.month) {
					return -1;
				} else {
					return 1;
				}
			}
		}
	}

	public static String getDateKey(int year, int month) {
		// Used in the observations HashMap
		// year = 1995, month = 6, becomes String key "199506"
		String monthString = String.format("%02d", month); // Leading zero, ensures e.g. April is '04', not '4'
		String dateKey = year + monthString;
		return dateKey;
	}

	public String getDateKey() {
		return getDateKey(this.year, this.month);
	}

	public int getYear() {
		return year;
	}

	public int getMonth() {
		return month;
	}

	public Double getMaxTemp() {
		return maxTemp;
	}

	public Double getMinTemp() {
		return minTemp;
	}

	public Integer getFrostyDays() {
		return frostyDays;
	}

	public Double getRainInMM() {
		return rainInMM;
	}

	public Double getHoursOfSun() {
		return hoursOfSun;
	}

	// The CSV files contain the data as Strings, with blank fields stored as '---'
	// Converting into correct types before storing into WeatherObservation,
	// or leaving field blank in case of '---'
	public void setYear(String year) {
		if (!year.equals("---")) {
			this.year = Integer.valueOf(cleanInput(year));
		}
	}

	public void setMonth(String month) {
		if (!month.equals("---")) {
			this.month = Integer.valueOf(cleanInput(month));
		}
	}

	public void setMaxTemp(String maxTemp) {
		if (!maxTemp.equals("---")) {
			this.maxTemp = Double.valueOf(cleanInput(maxTemp));
		}
	}

	public void setMinTemp(String minTemp) {
		if (!minTemp.equals("---")) {
			this.minTemp = Double.valueOf(cleanInput(minTemp));
		}
	}

	public void setFrostyDays(String frostyDays) {
		if (!frostyDays.equals("---")) {
			this.frostyDays = Integer.valueOf(cleanInput(frostyDays));
		}
	}

	public void setRainInMM(String rainInMM) {
		if (!rainInMM.equals("---")) {
			this.rainInMM = Double.valueOf(cleanInput(rainInMM));
		}
	}

	public void setHoursOfSun(String hoursOfSun) {
		if (!hoursOfSun.equals("---")) {
			this.hoursOfSun = Double.valueOf(cleanInput(hoursOfSun));
		}
	}

	// Some values are marked with * (estimated value),
	// or # (Sunshine data taken from an automatic Kipp & Zonen sensor)
	// Method removes these characters to allow values to be parsed as
	// Integer/Double
	// TODO: Move this sanitisation to FileParser class
	private String cleanInput(String messy) {

		// Replace any found '*' or '#' with an empty string
		// '*' is a special character, so needs to be escaped with '\\'
		String clean = messy.replaceAll("\\*", "").replaceAll("#", "");
		return clean;
	}

}
