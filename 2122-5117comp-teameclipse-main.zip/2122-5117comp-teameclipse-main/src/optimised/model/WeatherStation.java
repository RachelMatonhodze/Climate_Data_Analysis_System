package optimised.model;
import java.util.TreeMap;

public class WeatherStation {
	private String name;
	public TreeMap<String, WeatherObservation> observations;

	public WeatherStation(String name, TreeMap<String, WeatherObservation> observations) {
		this.name = name;
		this.observations = observations;
	}
	
	@Override
	public String toString() {
		return getName();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
