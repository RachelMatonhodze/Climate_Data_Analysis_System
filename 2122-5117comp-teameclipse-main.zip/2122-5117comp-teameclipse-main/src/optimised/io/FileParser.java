package optimised.io;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Scanner;
import java.util.TreeMap;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import optimised.model.*;

public class FileParser {
	// Constant pointing to the folder where input .txt files are located
	private static final String TXT_DIRECTORY = "data/txt/";
	// Constant pointing to the folder where .CSV files are to be stored
	private static final String CSV_DIRECTORY = "data/csv/";

	public static void generateCSVs() {
		String[] fileNames = new File(TXT_DIRECTORY).list();
		for (String fileName : fileNames) {
			System.out.println("-------------" + fileName + "-------------");
			generateCSV(fileName);

		}

	}

	private static void generateCSV(String fileName) {
		String outputFile = "data/csv/" + fileName.split("\\.")[0] + ".csv";
		// Strip .txt, replace with .csv

		try (Scanner scanner = new Scanner(new FileReader("data/txt/" + fileName));
				CSVPrinter printer = new CSVPrinter(new FileWriter(outputFile), CSVFormat.DEFAULT)) {

			String stationName = scanner.nextLine().trim(); // First row is the station name

			String line;
			do { // Consume rows until header reached
				line = scanner.nextLine();
			} while (!line.equals("   yyyy  mm   tmax    tmin      af    rain     sun"));
			scanner.nextLine(); // Consume second header row, all future rows are data

			// Print station name and replacement header
			printer.printRecord(stationName);
			printer.printRecord("Year", "Month", "MaxTemp", "MinTemp", "FrostyDays", "RainInMm", "HoursOfSun");

			// Read data in, splitting along whitespace
			// Then add them as CSV records to new file

			int rowCounter = 1;
			while (scanner.hasNextLine()) {
				String[] values = scanner.nextLine().trim().split("\\s+");
				if (values.length > 7) {
					if (values[7].matches("Provisional|#|\\$")) {
						values = Arrays.copyOfRange(values, 0, 7);

					}
				}

				if (values.length > 7) {

					System.err.println(
							stationName + " row " + rowCounter + " has " + values.length + " columns, should have 7");
					System.err.print("Values: ");
					for (String string : values) {
						System.err.print(string + ", ");
					}
					System.err.println();
				}

				if (values.length < 7) {
					try {
						Integer.parseInt(values[0]);
						Integer.parseInt(values[1]);
					} catch (NumberFormatException e) {
						continue;
					}

					values = Arrays.copyOf(values, 7);
					values[6] = "---";

				}

				if (values.length < 7) {
					System.err.println(
							stationName + " row " + rowCounter + " has " + values.length + " columns, should have 7");
					System.err.print("Values: ");
					for (String string : values) {
						System.err.print(string + ", ");
					}
					System.err.println();
				}

				printer.printRecord((Object[]) values);
				rowCounter++;

			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static HashMap<String, WeatherStation> importWeatherData() throws IOException {
		HashMap<String, WeatherStation> stationMap = new HashMap<String, WeatherStation>();

		// Stores names of all files inside 'data/csv/' folder into array, 'files'
		String[] files = new File(CSV_DIRECTORY).list();

		// Read each file in turn
		for (String file : files) {
			if (file.matches("whitbydata.csv|nairndata.csv|lowestoftdata.csv")) {
				continue; // temp, these currently don't work
			}
			// Add 'data/csv/' to the start of the file name, to create a correct file path
			// (all paths are relative to project root).
			// e.g. 'cardiffdata.csv' becomes 'data/csv/cardiffdata.csv'
			file = CSV_DIRECTORY + file;

			// Reads all rows of 'file' into 'records'
			// 'records' can be iterated through using a for-each loop
			// .setHeader parameters should be set to column headings of the CSV file
			// Uses Apache Commons CSV Library:
			// https://commons.apache.org/proper/commons-csv/user-guide.html
			Iterable<CSVRecord> records = CSVFormat.Builder.create()
					.setHeader("Year", "Month", "MaxTemp", "MinTemp", "FrostyDays", "RainInMm", "HoursOfSun").build()
					.parse(new FileReader(file));

			// To store the name of each observation station, in the first row of the file
			String stationName = "";

			// Make a new TreeMap to store the file's observation data into
			TreeMap<String, WeatherObservation> observations = new TreeMap<String, WeatherObservation>();

			// Iterate through all CSV rows, previously read into 'records'
			for (CSVRecord record : records) {
				// First row contains observation station name
				// store for later and continue (move to next record)
				if (record.getRecordNumber() == 1) {
					stationName = record.get(0);
					continue;
				}

				// Second row only contains column headings, no actual data
				if (record.getRecordNumber() == 2) {
					continue;
				}

				// Rows after the second contain observation data
				// Create a blank WeatherObservation object
				WeatherObservation observation = new WeatherObservation();

				// Store each of the values of the CSV row into the object
				// Giving column headings to .setHeader earlier when creating 'records' means we
				// can reference each column by name
				observation.setYear(record.get("Year"));
				observation.setMonth(record.get("Month"));
				observation.setMaxTemp(record.get("MaxTemp"));
				observation.setMinTemp(record.get("MinTemp"));
				observation.setFrostyDays(record.get("FrostyDays"));
				observation.setRainInMM(record.get("RainInMm"));
				observation.setHoursOfSun(record.get("HoursOfSun"));

				// Add the observation to the TreeMap of observations, with a date key in the
				// form YYYYMM
				observations.put(observation.getDateKey(), observation);
			}

			// Make a new WeatherStation object to store the TreeMap of weather
			// observations
			WeatherStation station = new WeatherStation(stationName, observations);

			// Add it to the map of all the stations
			stationMap.put(stationName, station);
		}

		// Return full map of WeatherStations
		return stationMap;

	}
}
